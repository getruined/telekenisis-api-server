<?php
/**
 * Plugin Name:       TelekenesisIT Content Sync
 * Plugin URI:        https://telekenisisit.ca/
 * Description:       Syncs content from the Telekenisisit app to your WordPress site.
 * Version:           1.0.0
 * Author:            Brian McGill / Telekenisisit
 * Author URI:        https://telekenisisit.ca/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       tcs
 * Domain Path:       /languages
 *
 * (FINAL v5 - This version includes the critical file loading fix)
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Define constants
 */
define( 'TCS_PLUGIN_VERSION', '1.0.0' );
define( 'TCS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
class Telekenisisit_Content_Sync {

    /**
     * The unique identifier of this plugin.
     *
     * @access   protected
     * @var      string    $plugin_name    The string used to uniquely identify this plugin.
     */
    protected $plugin_name;

    /**
     * The current version of the plugin.
     *
     * @access   protected
     * @var      string    $version    The current version of the plugin.
     */
    protected $version;

    /**
     * Define the core functionality of the plugin.
     */
    public function __construct() {
        $this->plugin_name = 'telekenisisit-content-sync';
        $this->version = TCS_PLUGIN_VERSION;

        // Load all dependencies. This is the critical fix.
        $this->load_dependencies();

        // Set up the hooks
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }

    /**
     * Load the required dependencies for this plugin.
     *
     * This is the function that was broken and caused the fatal error.
     */
    private function load_dependencies() {

        /**
         * The class responsible for handling API communication.
         */
        require_once TCS_PLUGIN_DIR . 'includes/class-tcs-api-handler.php';

        /**
         * The class responsible for mapping content (used by shortcode/block).
         */
        require_once TCS_PLUGIN_DIR . 'includes/class-tcs-content-mapper.php';

        /**
         * The class responsible for defining all shortcodes.
         */
        require_once TCS_PLUGIN_DIR . 'includes/class-tcs-shortcodes.php';

        /**
         * The class responsible for creating the admin settings page.
         */
        require_once TCS_PLUGIN_DIR . 'admin/class-tcs-admin-settings.php';

        /**
         * The class responsible for "Pro" features like social import.
         */
        require_once TCS_PLUGIN_DIR . 'pro-features/class-tcs-social-importer.php';
    }

    /**
     * Register all of the hooks related to the admin area functionality
     * of the plugin.
     */
    private function define_admin_hooks() {
        // Instantiate the admin settings class
        $plugin_admin = new TCS_Admin_Settings();

        // This hook creates the "Settings > Telekenisisit Sync" menu link
        add_action( 'admin_menu', array( $plugin_admin, 'add_plugin_page' ) );

        // This hook registers the settings fields
        add_action( 'admin_init', array( $plugin_admin, 'page_init' ) );
    }

    /**
     * Register all of the hooks related to the public-facing functionality
     * of the plugin.
     */
    private function define_public_hooks() {
        // Instantiate the shortcode class
        $shortcode_handler = new TCS_Shortcodes();
        
        // This hook registers the shortcode [telekinesis_content id="..."]
        add_action( 'init', array( $shortcode_handler, 'register_shortcode' ) );

        // Instantiate the pro features class
        $pro_features = new TCS_Social_Importer();
        
        // These hooks inject the SEO snippets from the API
        add_action( 'wp_head', array( $pro_features, 'inject_head_snippets' ) );
        add_action( 'wp_footer', array( $pro_features, 'inject_footer_snippets' ) );
    }

} // End of class

/**
 * Begins execution of the plugin.
 */
function run_tcs_plugin() {
    $plugin = new Telekenisisit_Content_Sync();
}
run_tcs_plugin();