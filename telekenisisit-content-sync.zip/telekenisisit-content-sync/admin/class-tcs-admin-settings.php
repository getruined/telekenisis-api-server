<?php
/**
 * Creates the Admin Settings page.
 * (FINAL v5)
 *
 * @package TelekenisisContentSync
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

class TCS_Admin_Settings {

    /**
     * Holds the values to be used in the fields callbacks
     */
    private $options;

    /**
     * Start up
     */
    public function __construct() {
        // We don't need to do anything in the constructor for this class
        // The hooks are added in the main plugin file
    }

    /**
     * Add options page
     */
    public function add_plugin_page() {
        // This page will be under "Settings > Telekenisisit Sync"
        add_options_page(
            'Telekenisisit Sync Settings',      // Page title
            'Telekenisisit Sync',               // Menu title
            'manage_options',                   // Capability
            'tcs-admin-settings',               // Menu slug
            array( $this, 'create_admin_page' ) // Function to render the page
        );
    }

    /**
     * Options page callback
     */
    public function create_admin_page() {
        // Set class property
        $this->options = get_option( 'tcs_options' );
        ?>
        <div class="wrap">
            <h1>Telekenisisit Content Sync Settings</h1>
            <p>Enter your API key from the Telekenisisit App to connect your site.</p>
            <form method="post" action="options.php">
                <?php
                // This prints out all hidden settings fields
                settings_fields( 'tcs_option_group' );
                do_settings_sections( 'tcs-admin-settings' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    /**
     * Register and add settings
     */
    public function page_init() {
        register_setting(
            'tcs_option_group', // Option group
            'tcs_options', // Option name
            array( $this, 'sanitize' ) // Sanitize callback
        );

        add_settings_section(
            'tcs_setting_section', // ID
            'API Connection', // Title
            array( $this, 'print_section_info' ), // Callback
            'tcs-admin-settings' // Page
        );

        add_settings_field(
            'api_key', // ID
            'API Key', // Title
            array( $this, 'api_key_callback' ), // Callback
            'tcs-admin-settings', // Page
            'tcs_setting_section' // Section
        );

        // --- Pro Features Section ---
        // We will add this later, but the code is here.
        /*
        add_settings_section(
            'tcs_pro_section',
            'Pro Features',
            array( $this, 'print_pro_section_info' ),
            'tcs-admin-settings'
        );

        add_settings_field(
            'enable_social_import',
            'Enable Social-to-Blog',
            array( $this, 'enable_social_import_callback' ),
            'tcs-admin-settings',
            'tcs_pro_section'
        );

        add_settings_field(
            'import_as_draft',
            'Import Posts as Draft',
            array( $this, 'import_as_draft_callback' ),
            'tcs-admin-settings',
            'tcs_pro_section'
        );
        */
    }

    /**
     * Sanitize each setting field as needed
     *
     * @param array $input Contains all settings fields as array keys
     */
    public function sanitize( $input ) {
        $new_input = array();

        if ( isset( $input['api_key'] ) ) {
            $new_input['api_key'] = sanitize_text_field( $input['api_key'] );
        }
        
        // Sanitize pro features if they exist
        if ( isset( $input['enable_social_import'] ) ) {
            $new_input['enable_social_import'] = absint( $input['enable_social_import'] );
        }
        if ( isset( $input['import_as_draft'] ) ) {
            $new_input['import_as_draft'] = absint( $input['import_as_draft'] );
        }

        return $new_input;
    }

    /**
     * Print the Section text
     */
    public function print_section_info() {
        print 'Enter your settings below:';
    }

    /**
     * Get the settings option array and print one of its values
     */
    public function api_key_callback() {
        printf(
            '<input type="password" id="api_key" name="tcs_options[api_key]" value="%s" class="regular-text" />',
            isset( $this->options['api_key'] ) ? esc_attr( $this->options['api_key'] ) : ''
        );
    }
    
    // --- Pro Feature Callbacks ---
    
    public function print_pro_section_info() {
        print 'Configure automated features:';
    }
    
    public function enable_social_import_callback() {
        printf(
            '<input type="checkbox" id="enable_social_import" name="tcs_options[enable_social_import]" value="1" %s />
             <label for="enable_social_import">Automatically create blog posts from new social posts.</label>',
            isset( $this->options['enable_social_import'] ) && $this->options['enable_social_import'] == 1 ? 'checked' : ''
        );
    }
    
    public function import_as_draft_callback() {
        printf(
            '<input type="checkbox" id="import_as_draft" name="tcs_options[import_as_draft]" value="1" %s />
             <label for="import_as_draft">New posts are created as drafts (Recommended). If unchecked, posts will be published immediately.</label>',
            isset( $this->options['import_as_draft'] ) && $this->options['import_as_draft'] == 1 ? 'checked' : ''
        );
    }

}