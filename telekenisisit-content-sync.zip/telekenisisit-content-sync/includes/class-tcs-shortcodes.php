<?php
/**
 * Registers all shortcodes for the plugin.
 * (FINAL v5)
 *
 * @package TelekenisisContentSync
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

class TCS_Shortcodes {

    /**
     * The content mapper.
     * @var TCS_Content_Mapper
     */
    private $mapper;

    /**
     * Constructor.
     */
    public function __construct() {
        // This is safe because the main plugin file loaded the mapper first.
        $this->mapper = new TCS_Content_Mapper();
    }

    /**
     * Registers the main shortcode.
     * This function is called by add_action('init', ...) in the main plugin file.
     */
    public function register_shortcode() {
        add_shortcode( 'telekinesis_content', array( $this, 'render_content_shortcode' ) );
    }

    /**
     * Renders the shortcode [telekinesis_content id="..."]
     *
     * @param array $atts The shortcode attributes.
     * @return string The HTML output for the shortcode.
     */
    public function render_content_shortcode( $atts ) {
        // Normalize attributes to lowercase and set defaults
        $atts = shortcode_atts(
            array(
                'id' => '', // The default is an empty string
            ),
            $atts,
            'telekinesis_content'
        );

        $content_slug = sanitize_text_field( $atts['id'] );

        // Pass the slug to the content mapper to get the HTML
        return $this->mapper->get_content_by_slug( $content_slug );
    }
}