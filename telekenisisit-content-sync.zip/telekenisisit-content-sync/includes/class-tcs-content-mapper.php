<?php
/**
 * Handles mapping content from the API to WordPress.
 * (FINAL v7 - This version has SUPERIOR error logging)
 *
 * @package TelekenisisContentSync
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

class TCS_Content_Mapper {

    /**
     * API Handler instance
     * @var TCS_API_Handler
     */
    private $api;

    /**
     * Constructor.
     */
    public function __construct() {
        // We instantiate the API handler here to use it.
        // This file is loaded by the main plugin file, so TCS_API_Handler is available.
        $this->api = new TCS_API_Handler();
    }

    /**
     * Gets the HTML content for a specific content slug.
     * This is the function called by the shortcode.
     *
     * @param string $slug The unique slug for the content.
     * @return string The HTML content or an error message.
     */
    public function get_content_by_slug( $slug ) {
        if ( empty( $slug ) ) {
            return $this->format_error_message( 'No ID/slug provided.' );
        }

        $response = $this->api->get_content_snippet( $slug );

        // Check for WordPress errors
        if ( is_wp_error( $response ) ) {
            return $this->format_error_message( $response->get_error_message() );
        }

        // Check for API-side errors (like "content not found")
        if ( ! isset( $response['success'] ) || $response['success'] !== true ) {
            $message = isset( $response['message'] ) ? $response['message'] : 'Content not found.';
            return $this->format_error_message( $message );
        }

        // Check for the actual data
        if ( ! isset( $response['data']['content_html'] ) ) {
            return $this->format_error_message( 'API response did not contain "content_html".' );
        }

        // Success! Return the raw HTML content.
        return $response['data']['content_html'];
    }

    /**
     * Formats an error message for display on the front-end.
     * We only show detailed errors if the user is an administrator.
     *
     * THIS FUNCTION IS NOW FIXED.
     *
     * @param string $message The error message.
     * @return string The formatted HTML error message.
     */
    private function format_error_message( $message ) {
        $display_message = '<!-- [Telekenisisit Plugin Error: ' . esc_html( $message ) . '] -->';

        // Only show detailed errors to logged-in admins
        if ( current_user_can( 'manage_options' ) ) {
            $display_message = '<p style="color: red; border: 1px solid red; padding: 10px;">[Telekenisisit Plugin Error: ' . esc_html( $message ) . ']</p>';
        }

        return $display_message; // This now returns the visible error
    }
}