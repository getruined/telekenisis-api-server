<?php
/**
 * Handles all communication with the Telekenisisit API.
 * (FINAL v7 - This version has SUPERIOR error logging)
 *
 * @package TelekenisisContentSync
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

class TCS_API_Handler {

    /**
     * The base URL for the Telekenisisit API.
     * This is the live, public URL from Render.com.
     * @var string
     */
    private $api_base_url = 'https://telekenisis-api-server.onrender.com/v1/';

    /**
     * The API key.
     * @var string
     */
    private $api_key;

    /**
     * Constructor.
     */
    public function __construct() {
        $options = get_option( 'tcs_options' );
        $this->api_key = isset( $options['api_key'] ) ? $options['api_key'] : '';
    }

    /**
     * Fetches a specific content snippet from the API.
     *
     * @param string $slug The unique slug for the content.
     * @return array|WP_Error The API response or an error.
     */
    public function get_content_snippet( $slug ) {
        // Use a transient to cache the API response for 5 minutes
        $transient_key = 'tcs_snippet_' . sanitize_key( $slug );
        $cached_data = get_transient( $transient_key );

        if ( false !== $cached_data ) {
            // FOR DEBUGGING, let's clear the cache on every load.
            // This is "bad" for performance but "good" for finding this bug.
            delete_transient( $transient_key );
        }

        $url = $this->api_base_url . 'content/' . sanitize_text_field( $slug );
        $response = $this->make_api_request( $url );

        if ( is_wp_error( $response ) ) {
            set_transient( $transient_key, $response, 1 * MINUTE_IN_SECONDS );
            return $response;
        }
        
        set_transient( $transient_key, $response, 5 * MINUTE_IN_SECONDS );
        return $response;
    }

    /**
     * Fetches new social posts from the API since a given timestamp.
     *
     * @param int $timestamp The UNIX timestamp of the last import.
     * @return array|WP_Error The API response or an error.
     */
    public function get_social_posts( $timestamp = 0 ) {
        $url = add_query_arg( 'since', (int) $timestamp, $this->api_base_url . 'social_posts' );
        return $this->make_api_request( $url );
    }
    
    /**
     * Fetches the global SEO snippets from the API.
     *
     * @return array|WP_Error The API response or an error.
     */
    public function get_seo_snippets() {
        $transient_key = 'tcs_seo_snippets';
        delete_transient( $transient_key ); // DEBUG: Clear cache

        $cached_snippets = get_transient( $transient_key );

        if ( false !== $cached_snippets ) {
            return $cached_snippets; 
        }

        $url = $this->api_base_url . 'seo_snippets';
        $response = $this->make_api_request( $url );

        if ( is_wp_error( $response ) ) {
            set_transient( $transient_key, $response, 5 * MINUTE_IN_SECONDS );
            return $response;
        }

        if ( ! isset( $response['data'] ) ) {
            $error = new WP_Error( 'api_response_invalid', 'API response did not contain "data" for SEO snippets.' );
            set_transient( $transient_key, $error, 5 * MINUTE_IN_SECONDS );
            return $error;
        }

        $snippets = $response['data']; 
        set_transient( $transient_key, $snippets, 1 * HOUR_IN_SECONDS );
        return $snippets;
    }


    /**
     * Makes the actual cURL request to the API.
     *
     * @param string $url The full URL to request.
     * @return array|WP_Error Decoded JSON response or an error object.
     */
    private function make_api_request( $url ) {
        if ( empty( $this->api_key ) ) {
            return new WP_Error( 'no_api_key', 'API Key is not set in Telekenisisit Sync settings.' );
        }

        $args = array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type'  => 'application/json',
            ),
            'timeout' => 30,
        );

        $response = wp_remote_get( $url, $args );

        if ( is_wp_error( $response ) ) {
            return $response; // This is a WordPress-level error (e.g., timeout)
        }

        $body = wp_remote_retrieve_body( $response );
        $http_code = wp_remote_retrieve_response_code( $response );

        if ( $http_code >= 400 ) {
            // THIS IS THE NEW, SMARTER ERROR HANDLER
            $error_data = json_decode( $body, true );
            
            // Try to find a 'message' key
            if ( isset( $error_data['message'] ) ) {
                $message = $error_data['message'];
            } 
            // Try to find an 'error' key
            else if ( isset( $error_data['error'] ) ) {
                $message = $error_data['error'];
            }
            // If we can't find anything, just print the whole body
            else if ( ! empty( $body ) ) {
                $message = 'Unknown API Error. Full response: ' . esc_html( $body );
            }
            // Fallback
            else {
                $message = 'An unknown API error occurred with no response body.';
            }
            
            return new WP_Error( 'api_error_' . $http_code, $message );
        }

        $data = json_decode( $body, true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'json_decode_error', 'Failed to decode API response. Body: ' . esc_html($body) );
        }

        return $data;
    }
}