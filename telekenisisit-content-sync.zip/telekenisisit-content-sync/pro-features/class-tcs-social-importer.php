<?php
/**
 * Handles all "Pro" features like social import and SEO snippets.
 * (FINAL v6 - This version fixes the fatal error on page load)
 *
 * @package TelekenisisContentSync
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

class TCS_Social_Importer {

    /**
     * API Handler instance
     * @var TCS_API_Handler
     */
    private $api;

    /**
     * Plugin options
     * @var array
     */
    private $options;

    /**
     * Constructor.
     */
    public function __construct() {
        // This is safe because the main plugin file loaded the API handler first.
        $this->api = new TCS_API_Handler();
        $this->options = get_option( 'tcs_options' );

        // This hook will be added in a future version to set up the cron job.
        // add_action( 'tcs_social_import_cron', array( $this, 'run_social_importer' ) );
    }

    /**
     * Runs the social post importer.
     * This is called by a WP-Cron job.
     */
    public function run_social_importer() {
        // Check if the feature is enabled in settings
        if ( ! isset( $this->options['enable_social_import'] ) || $this->options['enable_social_import'] != 1 ) {
            return; // Feature is not enabled
        }

        // Get the timestamp of the last successful import
        $last_import_timestamp = get_option( 'tcs_last_import_timestamp', 0 );
        $current_time = time(); // We'll update the timestamp *after* a successful import

        // Fetch new posts from the API
        $response = $this->api->get_social_posts( $last_import_timestamp );

        if ( is_wp_error( $response ) || ! isset( $response['data'] ) || empty( $response['data'] ) ) {
            // Log error or do nothing
            return;
        }

        $posts = $response['data'];
        $import_as_draft = isset( $this->options['import_as_draft'] ) && $this->options['import_as_draft'] == 1;

        foreach ( $posts as $post ) {
            // Check if this post has already been imported
            if ( $this->has_post_been_imported( $post['id'] ) ) {
                continue; // Skip this post
            }

            // Create new post
            $new_post_args = array(
                'post_title'   => sanitize_text_field( $post['title'] ),
                'post_content' => wp_kses_post( $post['content_html'] ), // Allow HTML
                'post_status'  => $import_as_draft ? 'draft' : 'publish',
                'post_type'    => 'post',
            );

            $new_post_id = wp_insert_post( $new_post_args );

            if ( $new_post_id && ! is_wp_error( $new_post_id ) ) {
                // Store the original API post ID to prevent duplicates
                update_post_meta( $new_post_id, '_tcs_api_post_id', sanitize_text_field( $post['id'] ) );
            }
        }

        // After successfully importing, update the last import timestamp
        update_option( 'tcs_last_import_timestamp', $current_time );
    }

    /**
     * Checks if a post from the API has already been imported.
     *
     * @param string $api_post_id The unique ID from the Telekenisisit API.
     * @return bool True if post exists, false otherwise.
     */
    private function has_post_been_imported( $api_post_id ) {
        $args = array(
            'post_type'  => 'post',
            'meta_key'   => '_tcs_api_post_id',
            'meta_value' => sanitize_text_field( $api_post_id ),
            'posts_per_page' => 1,
            'fields' => 'ids', // Only need to know if one exists
        );

        $query = new WP_Query( $args );
        return $query->have_posts();
    }


    /**
     * Injects SEO snippets into the <head> section.
     * THIS IS THE FUNCTION THAT WAS FIXED.
     */
    public function inject_head_snippets() {
        // It must call the function from the API handler: $this->api->get_seo_snippets()
        $snippets = $this->api->get_seo_snippets();
        
        if ( ! is_wp_error( $snippets ) && ! empty( $snippets['head_snippet'] ) ) {
            echo "\n<!-- Telekenisisit SEO Snippet (Head) -->\n";
            echo $snippets['head_snippet']; // Echos raw HTML/Script
            echo "\n<!-- End Telekenisisit SEO Snippet -->\n";
        }
    }

    /**
     * Injects SEO snippets into the footer.
     * THIS IS THE FUNCTION THAT WAS FIXED.
     */
    public function inject_footer_snippets() {
        // It must call the function from the API handler: $this->api->get_seo_snippets()
        $snippets = $this->api->get_seo_snippets(); 
        
        if ( ! is_wp_error( $snippets ) && ! empty( $snippets['footer_snippet'] ) ) {
            echo "\n<!-- Telekenisisit SEO Snippet (Footer) -->\n";
            echo $snippets['footer_snippet']; // Echos raw HTML/Script
            echo "\n<!-- End Telekenisisit SEO Snippet -->\n";
        }
    }

}